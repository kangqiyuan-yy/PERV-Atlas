"""PERV Website backend.

Single-file Flask application that:
- preprocesses sequence/* (xlsx, bed, fasta) into data/*.json on startup
- exposes JSON APIs for the two website sections
- serves Jinja2 templates and static assets

Run:
    pip install -r requirements.txt
    flask --app app run --host 0.0.0.0 --port 5000
or for production:
    gunicorn -w 2 -b 0.0.0.0:5000 app:app
"""

from __future__ import annotations

import io
import json
import os
import re
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from flask import (
    Flask,
    abort,
    jsonify,
    render_template,
    request,
    send_from_directory,
)


BASE_DIR = Path(__file__).resolve().parent
SEQ_DIR = BASE_DIR / "sequence"
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

XLSX_PATH = SEQ_DIR / "1165.intact.PERV.infomation.xlsx"
ALL_FA_PATH = SEQ_DIR / "my.final.fa"
PASS_FA_PATH = SEQ_DIR / "pass.139.fa"
ORF_BED_PATH = SEQ_DIR / "ORF.combine.HTML.bed"
DOMAIN_BED_PATH = SEQ_DIR / "domin.combine.HTML.bed"

META_JSON = DATA_DIR / "meta_1165.json"
ORF_JSON = DATA_DIR / "orf_index.json"
DOMAIN_JSON = DATA_DIR / "domain_index.json"
SEQ_OFFSETS_JSON = DATA_DIR / "seq_offsets.json"

DOWNLOAD_WHITELIST = {
    "my.final.fa",
    "pass.139.fa",
    "1165.intact.PERV.infomation.xlsx",
    "ORF.combine.HTML.bed",
    "domin.combine.HTML.bed",
}


# ---------------------------------------------------------------------------
# Sequence utilities: standard codon table, translation, reverse complement
# ---------------------------------------------------------------------------

STANDARD_CODON_TABLE: dict[str, str] = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V",
    "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}

_COMPLEMENT_TABLE = str.maketrans("ACGTNacgtn", "TGCANtgcan")


def reverse_complement(seq: str) -> str:
    return seq.translate(_COMPLEMENT_TABLE)[::-1]


def translate_dna(seq: str, *, to_stop: bool = False) -> str:
    """Translate DNA using the standard codon table.

    Unknown codons (non-ACGT or partial trailing codon) are emitted as 'X'.
    `to_stop=True` truncates at the first in-frame stop codon (excluding the
    stop symbol from the output).
    """
    seq = seq.upper()
    out: list[str] = []
    for i in range(0, len(seq) - 2, 3):
        codon = seq[i : i + 3]
        aa = STANDARD_CODON_TABLE.get(codon, "X")
        if aa == "*" and to_stop:
            break
        out.append(aa)
    return "".join(out)


def fasta_wrap(seq: str, width: int = 60) -> str:
    return "\n".join(seq[i : i + width] for i in range(0, len(seq), width))


# ---------------------------------------------------------------------------
# Data preprocessing
# ---------------------------------------------------------------------------

XLSX_NS = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def parse_xlsx(path: Path) -> list[dict[str, Any]]:
    """Parse the metadata xlsx into a list of records using only stdlib.

    Row 1 is a title row, row 2 is the header. Returns dict per data row.
    """
    with zipfile.ZipFile(path) as z:
        ss_root = ET.fromstring(z.read("xl/sharedStrings.xml"))
        strings = [
            "".join(t.text or "" for t in si.findall(".//a:t", XLSX_NS))
            for si in ss_root.findall("a:si", XLSX_NS)
        ]
        sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))

    def cell_value(c: ET.Element) -> str:
        t = c.attrib.get("t", "")
        v = c.find("a:v", XLSX_NS)
        if t == "inlineStr":
            return "".join(x.text or "" for x in c.findall(".//a:t", XLSX_NS))
        if v is None or v.text is None:
            return ""
        if t == "s":
            return strings[int(v.text)]
        return v.text

    rows = sheet.findall(".//a:row", XLSX_NS)
    if len(rows) < 3:
        return []

    # Row 2 (index 1) is the header per inspection of the file.
    header = [cell_value(c) for c in rows[1].findall("a:c", XLSX_NS)]
    records: list[dict[str, Any]] = []
    for r in rows[2:]:
        cells = [cell_value(c) for c in r.findall("a:c", XLSX_NS)]
        if not cells or not cells[0]:
            continue
        rec = {}
        for i, key in enumerate(header):
            rec[key] = cells[i] if i < len(cells) else ""
        # numeric coercions
        for k in ("Identity", "Kimura.distance"):
            try:
                rec[k] = float(rec.get(k, "")) if rec.get(k, "") != "" else None
            except ValueError:
                pass
        try:
            it = rec.get("Insertion_Time", "")
            rec["Insertion_Time"] = int(float(it)) if it != "" else None
        except ValueError:
            pass
        records.append(rec)
    return records


def parse_bed(path: Path) -> dict[str, list[dict[str, Any]]]:
    out: dict[str, list[dict[str, Any]]] = defaultdict(list)
    with path.open("r", encoding="utf-8") as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) < 4:
                continue
            sid = parts[0]
            try:
                start = int(parts[1])
                end = int(parts[2])
            except ValueError:
                continue
            name = parts[3]
            strand = parts[5] if len(parts) > 5 and parts[5] in {"+", "-"} else "+"
            out[sid].append(
                {"name": name, "start": start, "end": end, "strand": strand}
            )
    for sid in out:
        out[sid].sort(key=lambda r: (r["start"], r["end"]))
    return dict(out)


def build_fasta_offsets(path: Path) -> dict[str, dict[str, int]]:
    """Index a FASTA file into {seq_id: {seq_start, seq_end, length}} byte offsets.

    `seq_start` points to the first byte of sequence data after the header line;
    `seq_end` points to the byte right after the last sequence byte (exclusive).
    Sequence lines may contain newlines that we strip when reading.
    """
    index: dict[str, dict[str, int]] = {}
    with path.open("rb") as fh:
        data = fh.read()
    pos = 0
    n = len(data)
    while pos < n:
        if data[pos : pos + 1] != b">":
            # find next header
            nxt = data.find(b"\n>", pos)
            if nxt == -1:
                break
            pos = nxt + 1
            continue
        header_end = data.find(b"\n", pos)
        if header_end == -1:
            break
        header = data[pos + 1 : header_end].decode("utf-8", errors="replace").strip()
        sid = header.split()[0] if header else ""
        seq_start = header_end + 1
        next_header = data.find(b"\n>", seq_start)
        if next_header == -1:
            seq_end = n
            pos = n
        else:
            seq_end = next_header  # newline before '>'
            pos = next_header + 1
        # compute pure sequence length without newlines / whitespace
        block = data[seq_start:seq_end]
        seq_len = sum(1 for b in block if b not in (10, 13, 32, 9))
        if sid:
            index[sid] = {
                "seq_start": seq_start,
                "seq_end": seq_end,
                "length": seq_len,
            }
    return index


def read_fasta_full(path: Path, offsets: dict[str, int]) -> str:
    """Read the full sequence (concatenated, whitespace stripped) from byte offsets."""
    with path.open("rb") as fh:
        fh.seek(offsets["seq_start"])
        block = fh.read(offsets["seq_end"] - offsets["seq_start"])
    return re.sub(r"\s+", "", block.decode("ascii", errors="replace")).upper()


# ---------------------------------------------------------------------------
# Build / load index files
# ---------------------------------------------------------------------------

def _needs_rebuild(target: Path, sources: list[Path]) -> bool:
    if not target.exists():
        return True
    target_mtime = target.stat().st_mtime
    return any(s.exists() and s.stat().st_mtime > target_mtime for s in sources)


def build_indexes(force: bool = False) -> None:
    if force or _needs_rebuild(META_JSON, [XLSX_PATH]):
        meta = parse_xlsx(XLSX_PATH)
        META_JSON.write_text(json.dumps(meta, ensure_ascii=False))
    if force or _needs_rebuild(ORF_JSON, [ORF_BED_PATH]):
        ORF_JSON.write_text(json.dumps(parse_bed(ORF_BED_PATH), ensure_ascii=False))
    if force or _needs_rebuild(DOMAIN_JSON, [DOMAIN_BED_PATH]):
        DOMAIN_JSON.write_text(
            json.dumps(parse_bed(DOMAIN_BED_PATH), ensure_ascii=False)
        )
    if force or _needs_rebuild(SEQ_OFFSETS_JSON, [PASS_FA_PATH]):
        SEQ_OFFSETS_JSON.write_text(
            json.dumps(build_fasta_offsets(PASS_FA_PATH), ensure_ascii=False)
        )


def _load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# Flask app
# ---------------------------------------------------------------------------

app = Flask(__name__, static_folder="static", template_folder="templates")

# build indexes once on import (safe across worker processes; idempotent)
build_indexes(force=False)

META: list[dict[str, Any]] = _load_json(META_JSON)
ORF_INDEX: dict[str, list[dict[str, Any]]] = _load_json(ORF_JSON)
DOMAIN_INDEX: dict[str, list[dict[str, Any]]] = _load_json(DOMAIN_JSON)
SEQ_OFFSETS: dict[str, dict[str, int]] = _load_json(SEQ_OFFSETS_JSON)


# -- pages ------------------------------------------------------------------

@app.route("/")
def page_index():
    return render_template("index.html")


@app.route("/overview")
def page_overview():
    return render_template("overview.html")


@app.route("/browser")
def page_browser():
    return render_template("browser.html")


# -- overview APIs ----------------------------------------------------------

def _hist(values: list[float], bins: int = 20) -> dict[str, list]:
    vals = [v for v in values if isinstance(v, (int, float))]
    if not vals:
        return {"edges": [], "counts": []}
    lo, hi = min(vals), max(vals)
    if lo == hi:
        return {"edges": [lo, hi + 1e-9], "counts": [len(vals)]}
    width = (hi - lo) / bins
    edges = [lo + i * width for i in range(bins + 1)]
    counts = [0] * bins
    for v in vals:
        idx = int((v - lo) / width)
        if idx == bins:
            idx = bins - 1
        counts[idx] += 1
    return {"edges": edges, "counts": counts}


@app.route("/api/overview/stats")
def api_overview_stats():
    total = len(META)
    type_counter = Counter(r.get("ERV.type", "") for r in META)
    group_counter = Counter(r.get("Group", "") for r in META)
    abbr_counter = Counter(r.get("Abbretiation", "") for r in META)

    identity_vals = [r.get("Identity") for r in META if r.get("Identity") is not None]
    insertion_vals = [
        r.get("Insertion_Time") for r in META if r.get("Insertion_Time") is not None
    ]
    kimura_vals = [
        r.get("Kimura.distance") for r in META if r.get("Kimura.distance") is not None
    ]

    abbr_sorted = sorted(abbr_counter.items(), key=lambda kv: -kv[1])
    return jsonify(
        {
            "total": total,
            "type_counts": dict(type_counter),
            "group_counts": dict(group_counter),
            "abbr_counts": [{"name": k, "count": v} for k, v in abbr_sorted],
            "identity_hist": _hist(identity_vals, bins=20),
            "insertion_hist": _hist(insertion_vals, bins=20),
            "kimura_hist": _hist(kimura_vals, bins=20),
        }
    )


@app.route("/api/overview/table")
def api_overview_table():
    q = request.args.get("q", "").strip().lower()
    erv_type = request.args.get("type", "").strip()
    group = request.args.get("group", "").strip()
    page = max(1, int(request.args.get("page", "1") or "1"))
    size = max(1, min(200, int(request.args.get("size", "25") or "25")))

    rows = META
    if q:
        rows = [r for r in rows if q in str(r.get("Sequence.ID", "")).lower()]
    if erv_type:
        rows = [r for r in rows if r.get("ERV.type") == erv_type]
    if group:
        rows = [r for r in rows if r.get("Group") == group]

    total = len(rows)
    start = (page - 1) * size
    end = start + size
    return jsonify(
        {
            "total": total,
            "page": page,
            "size": size,
            "rows": rows[start:end],
        }
    )


# -- pass.139 sequence APIs --------------------------------------------------

@app.route("/api/sequences/pass")
def api_sequences_pass():
    items = [
        {"id": sid, "length": SEQ_OFFSETS[sid]["length"]}
        for sid in sorted(SEQ_OFFSETS.keys())
    ]
    return jsonify({"total": len(items), "items": items})


def _get_full_seq(sid: str) -> str:
    if sid not in SEQ_OFFSETS:
        abort(404, description=f"sequence {sid} not found")
    return read_fasta_full(PASS_FA_PATH, SEQ_OFFSETS[sid])


@app.route("/api/sequences/<sid>/regions")
def api_sequence_regions(sid: str):
    kind = request.args.get("kind", "orf").lower()
    if kind == "orf":
        regions = ORF_INDEX.get(sid, [])
    elif kind == "domain":
        regions = DOMAIN_INDEX.get(sid, [])
    else:
        abort(400, description="kind must be 'orf' or 'domain'")
    if sid not in SEQ_OFFSETS:
        abort(404, description=f"sequence {sid} not found")
    return jsonify(
        {
            "id": sid,
            "length": SEQ_OFFSETS[sid]["length"],
            "kind": kind,
            "regions": regions,
        }
    )


def _slice_region(sid: str, start: int, end: int, strand: str) -> str:
    full = _get_full_seq(sid)
    if start < 0 or end > len(full) or start >= end:
        abort(400, description="invalid start/end")
    sub = full[start:end]
    if strand == "-":
        sub = reverse_complement(sub)
    return sub


@app.route("/api/sequences/<sid>/dna")
def api_sequence_dna(sid: str):
    try:
        start = int(request.args["start"])
        end = int(request.args["end"])
    except (KeyError, ValueError):
        abort(400, description="start and end query params required")
    strand = request.args.get("strand", "+")
    name = request.args.get("name", "")
    sub = _slice_region(sid, start, end, strand)
    full_len = SEQ_OFFSETS[sid]["length"]
    return jsonify(
        {
            "id": sid,
            "name": name,
            "start": start,
            "end": end,
            "strand": strand,
            "length": end - start,
            "full_length": full_len,
            "dna": sub,
            "fasta": f">{sid}|{name}|{start}-{end}|{strand}\n{fasta_wrap(sub)}\n",
        }
    )


@app.route("/api/sequences/<sid>/protein")
def api_sequence_protein(sid: str):
    try:
        start = int(request.args["start"])
        end = int(request.args["end"])
    except (KeyError, ValueError):
        abort(400, description="start and end query params required")
    strand = request.args.get("strand", "+")
    name = request.args.get("name", "")
    sub = _slice_region(sid, start, end, strand)
    protein = translate_dna(sub, to_stop=False)
    return jsonify(
        {
            "id": sid,
            "name": name,
            "start": start,
            "end": end,
            "strand": strand,
            "length": len(protein),
            "protein": protein,
            "fasta": f">{sid}|{name}|{start}-{end}|{strand}|protein\n{fasta_wrap(protein)}\n",
        }
    )


@app.route("/api/sequences/<sid>/all-protein")
def api_sequence_all_protein(sid: str):
    kind = request.args.get("kind", "orf").lower()
    if kind == "orf":
        regions = [r for r in ORF_INDEX.get(sid, []) if r["name"] != "LTR"]
    elif kind == "domain":
        regions = list(DOMAIN_INDEX.get(sid, []))
    else:
        abort(400, description="kind must be 'orf' or 'domain'")
    full = _get_full_seq(sid)
    chunks: list[str] = []
    items = []
    for r in regions:
        sub = full[r["start"] : r["end"]]
        if r.get("strand", "+") == "-":
            sub = reverse_complement(sub)
        protein = translate_dna(sub)
        chunks.append(
            f">{sid}|{r['name']}|{r['start']}-{r['end']}|{r.get('strand', '+')}|protein\n"
            + fasta_wrap(protein)
            + "\n"
        )
        items.append(
            {
                "name": r["name"],
                "start": r["start"],
                "end": r["end"],
                "strand": r.get("strand", "+"),
                "protein": protein,
            }
        )
    return jsonify({"id": sid, "kind": kind, "items": items, "fasta": "".join(chunks)})


# -- downloads --------------------------------------------------------------

@app.route("/download/<path:filename>")
def download_file(filename: str):
    if filename not in DOWNLOAD_WHITELIST:
        abort(404)
    return send_from_directory(SEQ_DIR, filename, as_attachment=True)


# -- error handler ----------------------------------------------------------

@app.errorhandler(400)
@app.errorhandler(404)
def _err(e):
    return jsonify({"error": str(e.description) if hasattr(e, "description") else str(e)}), e.code


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=True)
