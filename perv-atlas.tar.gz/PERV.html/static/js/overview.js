// Section 1: stats charts + searchable table.
(function () {
  const charts = {};
  let stats = null;
  const PALETTE = {
    gamma: '#2563eb',
    beta: '#f59e0b',
    east: '#10b981',
    west: '#ef4444',
    bar: '#6366f1',
    identity: '#0ea5e9',
    insertion: '#8b5cf6',
    kimura: '#14b8a6',
  };

  function initChart(id) {
    const el = document.getElementById(id);
    if (!el) return null;
    const c = echarts.init(el);
    charts[id] = c;
    window.addEventListener('resize', () => c.resize());
    return c;
  }

  function fmtPct(part, total) {
    if (!total) return '';
    return ((part / total) * 100).toFixed(1) + '%';
  }

  function renderType(stats) {
    const c = charts['chart-type'] || initChart('chart-type');
    const counts = stats.type_counts || {};
    const data = Object.keys(counts).map((k) => ({
      name: k,
      value: counts[k],
      itemStyle: { color: k.startsWith('γ') ? PALETTE.gamma : PALETTE.beta },
    }));
    c.setOption({
      tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
      legend: { bottom: 0 },
      series: [
        {
          type: 'pie',
          radius: ['45%', '70%'],
          label: { formatter: '{b}\n{d}%', fontSize: 12 },
          data,
        },
      ],
    });
  }

  function renderGroup(stats) {
    const c = charts['chart-group'] || initChart('chart-group');
    const counts = stats.group_counts || {};
    const data = Object.keys(counts).map((k) => ({
      name: k,
      value: counts[k],
      itemStyle: {
        color: k === 'Eastern' ? PALETTE.east : k === 'Western' ? PALETTE.west : '#94a3b8',
      },
    }));
    c.setOption({
      tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
      legend: { bottom: 0 },
      series: [
        {
          type: 'pie',
          radius: ['45%', '70%'],
          label: { formatter: '{b}\n{d}%', fontSize: 12 },
          data,
        },
      ],
    });
  }

  function renderAbbr(stats) {
    const c = charts['chart-abbr'] || initChart('chart-abbr');
    const items = stats.abbr_counts || [];
    c.setOption({
      grid: { left: 50, right: 30, top: 24, bottom: 60 },
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      xAxis: {
        type: 'category',
        data: items.map((x) => x.name),
        axisLabel: { rotate: 40, fontSize: 11 },
      },
      yAxis: { type: 'value' },
      series: [
        {
          type: 'bar',
          data: items.map((x) => x.count),
          itemStyle: { color: PALETTE.bar, borderRadius: [4, 4, 0, 0] },
          label: { show: true, position: 'top', fontSize: 10 },
        },
      ],
    });
  }

  function histToBars(h) {
    if (!h || !h.edges || h.edges.length < 2) return { x: [], y: [] };
    const x = [];
    for (let i = 0; i < h.edges.length - 1; i++) {
      const a = h.edges[i];
      const b = h.edges[i + 1];
      x.push(formatTick(a) + '–' + formatTick(b));
    }
    return { x, y: h.counts };
  }

  function formatTick(v) {
    if (v == null) return '';
    const abs = Math.abs(v);
    if (abs >= 1e6) return (v / 1e6).toFixed(1) + 'M';
    if (abs >= 1e3) return (v / 1e3).toFixed(1) + 'K';
    if (Number.isInteger(v)) return String(v);
    if (abs < 1) return v.toFixed(3);
    return v.toFixed(2);
  }

  function renderHist(id, h, color) {
    const c = charts[id] || initChart(id);
    const data = histToBars(h);
    c.setOption({
      grid: { left: 48, right: 16, top: 16, bottom: 60 },
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      xAxis: {
        type: 'category',
        data: data.x,
        axisLabel: { rotate: 35, fontSize: 10 },
      },
      yAxis: { type: 'value' },
      series: [
        {
          type: 'bar',
          data: data.y,
          itemStyle: { color, borderRadius: [3, 3, 0, 0] },
        },
      ],
    });
  }

  async function loadStats() {
    const res = await fetch('/api/overview/stats');
    stats = await res.json();
    document.getElementById('kpi-total').textContent = stats.total;
    const g = stats.type_counts['γ.ERV'] || 0;
    const b = stats.type_counts['β.ERV'] || 0;
    document.getElementById('kpi-gamma').textContent = g;
    document.getElementById('kpi-beta').textContent = b;
    document.getElementById('kpi-gamma-pct').textContent = fmtPct(g, stats.total);
    document.getElementById('kpi-beta-pct').textContent = fmtPct(b, stats.total);
    document.getElementById('kpi-groups').textContent = Object.keys(stats.group_counts).length;
    renderType(stats);
    renderGroup(stats);
    renderAbbr(stats);
    renderHist('chart-identity', stats.identity_hist, PALETTE.identity);
    renderHist('chart-insertion', stats.insertion_hist, PALETTE.insertion);
    renderHist('chart-kimura', stats.kimura_hist, PALETTE.kimura);
  }

  // ---------- table ----------
  const state = { page: 1, size: 25, q: '', type: '', group: '' };

  function rowHtml(r) {
    const typeTag = (r['ERV.type'] || '').startsWith('γ')
      ? '<span class="tag gamma">γ.ERV</span>'
      : (r['ERV.type'] || '').startsWith('β')
      ? '<span class="tag beta">β.ERV</span>'
      : '';
    const grpTag =
      r.Group === 'Eastern'
        ? '<span class="tag east">Eastern</span>'
        : r.Group === 'Western'
        ? '<span class="tag west">Western</span>'
        : escape(r.Group || '');
    return (
      '<tr>' +
      '<td>' + escape(r['Sequence.ID']) + '</td>' +
      '<td>' + typeTag + '</td>' +
      '<td>' + grpTag + '</td>' +
      '<td>' + escape(r.Abbretiation || '') + '</td>' +
      '<td>' + escape(r.Category || '') + '</td>' +
      '<td>' + escape(r.TE_type || '') + '</td>' +
      '<td>' + (r.Identity == null ? '' : Number(r.Identity).toFixed(4)) + '</td>' +
      '<td>' + (r.Insertion_Time == null ? '' : r.Insertion_Time) + '</td>' +
      '<td>' + (r['Kimura.distance'] == null ? '' : Number(r['Kimura.distance']).toFixed(4)) + '</td>' +
      '<td>' + escape(r.Motif || '') + '</td>' +
      '<td>' + escape(r.TSD || '') + '</td>' +
      '</tr>'
    );
  }

  function escape(s) {
    return String(s).replace(/[&<>"']/g, (m) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[m]);
  }

  async function loadTable() {
    const params = new URLSearchParams({
      q: state.q, type: state.type, group: state.group,
      page: state.page, size: state.size,
    });
    const res = await fetch('/api/overview/table?' + params.toString());
    const data = await res.json();
    const tb = document.querySelector('#meta-table tbody');
    if (!data.rows.length) {
      tb.innerHTML = '<tr><td colspan="11" class="empty-hint" data-i18n="ov.table.empty">No matching records</td></tr>';
      window.I18n.apply();
    } else {
      tb.innerHTML = data.rows.map(rowHtml).join('');
    }
    const totalPages = Math.max(1, Math.ceil(data.total / data.size));
    document.getElementById('p-info').textContent = `${data.page} / ${totalPages}`;
    document.getElementById('p-prev').disabled = data.page <= 1;
    document.getElementById('p-next').disabled = data.page >= totalPages;
    const totalEl = document.getElementById('t-total');
    totalEl.textContent =
      window.I18n.t('ov.table.total') + ' ' + data.total + ' ' + window.I18n.t('ov.table.records');
  }

  function bindTable() {
    let timer;
    const debounce = (fn, ms = 250) => () => {
      clearTimeout(timer);
      timer = setTimeout(fn, ms);
    };
    const trigger = () => { state.page = 1; loadTable(); };
    document.getElementById('t-q').addEventListener('input', (e) => {
      state.q = e.target.value;
      debounce(trigger)();
    });
    document.getElementById('t-type').addEventListener('change', (e) => {
      state.type = e.target.value; trigger();
    });
    document.getElementById('t-group').addEventListener('change', (e) => {
      state.group = e.target.value; trigger();
    });
    document.getElementById('p-prev').addEventListener('click', () => {
      if (state.page > 1) { state.page--; loadTable(); }
    });
    document.getElementById('p-next').addEventListener('click', () => {
      state.page++; loadTable();
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    bindTable();
    loadTable();
  });
  document.addEventListener('i18nchange', () => {
    if (stats) {
      // re-render to update tooltip text in current language (counts are language-agnostic)
      // For now, only the totals row uses i18n strings.
      loadTable();
    }
  });
})();
