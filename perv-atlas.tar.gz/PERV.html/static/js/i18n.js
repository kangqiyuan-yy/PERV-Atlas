// Minimal i18n helper: bilingual zh/en, switch via top-bar buttons.
(function () {
  const dict = {
    zh: {
      'site.title': 'PERV 数据展示平台',
      'site.brand': 'PERV Atlas',
      'nav.home': '首页',
      'nav.overview': '概览',
      'nav.browser': '序列浏览',
      'nav.docs': '说明',

      // home
      'home.hero.title': '完整 PERV 序列资源与功能注释浏览',
      'home.hero.desc': '本网站收录 1165 条完整猪内源性逆转录病毒（PERV）序列（1020 γ.ERV / 145 β.ERV），并对其中 139 条进行结构域和 ORF 的精细注释。提供原始数据下载与可交互的序列/蛋白浏览。',
      'home.card1.tag': '板块一',
      'home.card1.title': '1165 条 PERV 序列概览',
      'home.card1.desc': 'γ.ERV 与 β.ERV 比例、地理分组、品种缩写分布、Identity 与 Insertion_Time 直方图，以及可检索的元数据表格与 FASTA / Excel 下载。',
      'home.card1.cta': '进入概览',
      'home.card2.tag': '板块二',
      'home.card2.title': '139 条精注释序列浏览',
      'home.card2.desc': '点击序列 ID 查看 ORF 或结构域注释 track，按区间查看 DNA / 翻译后蛋白序列（FASTA 格式，可复制 / 下载）。',
      'home.card2.cta': '进入浏览器',

      // overview
      'ov.title': '1165 条完整 PERV 序列概览',
      'ov.subtitle': '基本组成、地理与品种分布，及关键指标分布。',
      'ov.kpi.total': '总序列数',
      'ov.kpi.gamma': 'γ.ERV',
      'ov.kpi.beta': 'β.ERV',
      'ov.kpi.groups': '地理分组',
      'ov.chart.type': 'γ.ERV vs β.ERV 比例',
      'ov.chart.group': 'Group 分布（Eastern / Western）',
      'ov.chart.abbr': 'Abbretiation 品种分布',
      'ov.chart.identity': 'Identity 分布',
      'ov.chart.insertion': 'Insertion_Time 分布',
      'ov.chart.kimura': 'Kimura 距离分布',
      'ov.table.title': '元数据表（可检索）',
      'ov.table.search': '搜索 Sequence.ID...',
      'ov.table.type': '所有 ERV.type',
      'ov.table.group': '所有 Group',
      'ov.table.empty': '没有匹配的记录',
      'ov.table.total': '共',
      'ov.table.records': '条',
      'ov.dl.title': '数据下载',
      'ov.dl.fa': '完整 1165 条 FASTA',
      'ov.dl.xlsx': '元数据 Excel (xlsx)',

      // browser
      'br.title': '139 条精注释序列浏览器',
      'br.subtitle': '左侧选择序列 ID，切换 ORF 或结构域视图，点击区间查看 DNA / 蛋白。',
      'br.search.id': '搜索 ID...',
      'br.mode.orf': 'ORF',
      'br.mode.domain': '结构域',
      'br.seq.dna': 'DNA',
      'br.seq.protein': '蛋白',
      'br.region.label': '区间',
      'br.empty': '请从左侧选择一个序列 ID',
      'br.copy': '复制',
      'br.copied': '已复制',
      'br.download': '下载 FASTA',
      'br.all_protein': '导出全部蛋白 (FASTA)',
      'br.highlight': '在整条序列中高亮显示该区间',
      'br.legend': '色块代表区间，鼠标悬停查看名称、范围、链方向；点击即可载入。',
      'br.dl.title': '原始注释 / 序列文件下载',
      'br.dl.fa': '139 条 FASTA',
      'br.dl.orf': 'ORF BED',
      'br.dl.domain': '结构域 BED',
      'br.protein.warn': '当前区间是 LTR，无蛋白翻译。请选择 GAG / POL / ENV。',
    },
    en: {
      'site.title': 'PERV Data Portal',
      'site.brand': 'PERV Atlas',
      'nav.home': 'Home',
      'nav.overview': 'Overview',
      'nav.browser': 'Browser',
      'nav.docs': 'Docs',

      'home.hero.title': 'Browse intact PERV sequences and functional annotations',
      'home.hero.desc': 'This portal hosts 1165 intact porcine endogenous retrovirus sequences (1020 γ.ERV / 145 β.ERV), with 139 of them carrying detailed ORF and domain annotations. Raw data and an interactive sequence/protein viewer are available.',
      'home.card1.tag': 'Section 1',
      'home.card1.title': 'Overview of 1165 intact PERVs',
      'home.card1.desc': 'γ vs β ratio, geographic groups, breed abbreviations, identity and insertion-time distributions, plus a searchable metadata table and FASTA/Excel downloads.',
      'home.card1.cta': 'Open overview',
      'home.card2.tag': 'Section 2',
      'home.card2.title': 'Annotated sequence browser (n=139)',
      'home.card2.desc': 'Click an ID to view ORF or domain tracks; pick a region to inspect its DNA or translated protein in FASTA format (copy / download).',
      'home.card2.cta': 'Open browser',

      'ov.title': 'Overview of 1165 intact PERVs',
      'ov.subtitle': 'Composition, geography, and key-metric distributions.',
      'ov.kpi.total': 'Total sequences',
      'ov.kpi.gamma': 'γ.ERV',
      'ov.kpi.beta': 'β.ERV',
      'ov.kpi.groups': 'Geographic groups',
      'ov.chart.type': 'γ.ERV vs β.ERV ratio',
      'ov.chart.group': 'Group distribution (Eastern / Western)',
      'ov.chart.abbr': 'Abbretiation (breed) distribution',
      'ov.chart.identity': 'Identity distribution',
      'ov.chart.insertion': 'Insertion_Time distribution',
      'ov.chart.kimura': 'Kimura distance distribution',
      'ov.table.title': 'Metadata table (searchable)',
      'ov.table.search': 'Search Sequence.ID...',
      'ov.table.type': 'All ERV.type',
      'ov.table.group': 'All Group',
      'ov.table.empty': 'No matching records',
      'ov.table.total': 'Total',
      'ov.table.records': 'records',
      'ov.dl.title': 'Downloads',
      'ov.dl.fa': 'Full 1165 FASTA',
      'ov.dl.xlsx': 'Metadata Excel (xlsx)',

      'br.title': 'Annotated sequence browser (n=139)',
      'br.subtitle': 'Pick an ID, toggle ORF or domain view, click a region to view DNA / protein.',
      'br.search.id': 'Search ID...',
      'br.mode.orf': 'ORF',
      'br.mode.domain': 'Domain',
      'br.seq.dna': 'DNA',
      'br.seq.protein': 'Protein',
      'br.region.label': 'Region',
      'br.empty': 'Pick a sequence ID on the left',
      'br.copy': 'Copy',
      'br.copied': 'Copied',
      'br.download': 'Download FASTA',
      'br.all_protein': 'Export all proteins (FASTA)',
      'br.highlight': 'Highlight this region within the full sequence',
      'br.legend': 'Each colored block is a region; hover for name / range / strand, click to load.',
      'br.dl.title': 'Raw files',
      'br.dl.fa': '139 FASTA',
      'br.dl.orf': 'ORF BED',
      'br.dl.domain': 'Domain BED',
      'br.protein.warn': 'LTR has no protein translation. Pick GAG / POL / ENV.',
    },
  };

  const I18n = {
    lang: localStorage.getItem('perv.lang') || 'zh',
    t(key) {
      return (dict[this.lang] && dict[this.lang][key]) || dict.zh[key] || key;
    },
    setLang(l) {
      if (!dict[l]) return;
      this.lang = l;
      localStorage.setItem('perv.lang', l);
      this.apply();
      document.dispatchEvent(new CustomEvent('i18nchange', { detail: { lang: l } }));
    },
    apply() {
      document.documentElement.lang = this.lang === 'zh' ? 'zh-CN' : 'en';
      document.querySelectorAll('[data-i18n]').forEach((el) => {
        el.textContent = this.t(el.dataset.i18n);
      });
      document.querySelectorAll('[data-i18n-ph]').forEach((el) => {
        el.setAttribute('placeholder', this.t(el.dataset.i18nPh));
      });
      document.querySelectorAll('[data-i18n-title]').forEach((el) => {
        el.setAttribute('title', this.t(el.dataset.i18nTitle));
      });
      const titleKey = document.body && document.body.dataset.titleKey;
      if (titleKey) document.title = this.t(titleKey);
      document.querySelectorAll('.lang-switch button').forEach((b) => {
        b.classList.toggle('active', b.dataset.lang === this.lang);
      });
    },
  };

  window.I18n = I18n;
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.lang-switch button').forEach((b) => {
      b.addEventListener('click', () => I18n.setLang(b.dataset.lang));
    });
    I18n.apply();
  });
})();
