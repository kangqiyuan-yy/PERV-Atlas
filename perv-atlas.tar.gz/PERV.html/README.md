# PERV Atlas

完整 PERV 序列资源与功能注释展示网站 / Browse intact PERV sequences and functional annotations.

- 板块一（`/overview`）：1165 条完整 PERV 元数据概览（1020 γ.ERV + 145 β.ERV）
- 板块二（`/browser`）：139 条精注释序列的 ORF / 结构域 track 浏览，支持 DNA / 蛋白翻译查看与下载

技术栈：Python 3 + Flask（后端）+ 原生 HTML/CSS/JS（前端）+ ECharts（图表）。中英文双语界面。

## 目录结构

```
PERV.html/
├── app.py                       # Flask 应用 + API + 数据预处理
├── requirements.txt
├── README.md
├── sequence/                    # 原始数据
│   ├── my.final.fa                       # 1165 条完整序列
│   ├── pass.139.fa                       # 139 条精注释序列
│   ├── 1165.intact.PERV.infomation.xlsx  # 元数据
│   ├── ORF.combine.HTML.bed              # ORF 注释 (LTR/GAG/POL/ENV)
│   └── domin.combine.HTML.bed            # 结构域注释 (GAG/AP/RT/RNaseH/INT/ENV)
├── data/                        # 启动时自动生成的 JSON 索引
│   ├── meta_1165.json
│   ├── orf_index.json
│   ├── domain_index.json
│   └── seq_offsets.json
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── overview.html
│   └── browser.html
└── static/
    ├── css/style.css
    └── js/{i18n.js, overview.js, browser.js, sequence.js}
```

## 安装与启动

需要 Python 3.8+。

```bash
# 1. 创建并激活虚拟环境
python3 -m venv .venv
source .venv/bin/activate

# 2. 安装依赖
pip install -r requirements.txt
# 国内可使用镜像: pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt

# 3. 启动开发服务器（默认 5000 端口）
python -m flask --app app run --host 0.0.0.0 --port 5000
# 或:
python app.py
```

打开浏览器访问 `http://<server-ip>:5000/`。

## 生产部署

使用 gunicorn 直接监听公网端口（也可前置 nginx 反向代理）：

```bash
gunicorn -w 2 -b 0.0.0.0:5000 app:app
```

systemd 单元示例（`/etc/systemd/system/perv.service`，按需修改路径与用户）：

```ini
[Unit]
Description=PERV Atlas
After=network.target

[Service]
WorkingDirectory=/home/ug2243/workspace/PERV.html
ExecStart=/home/ug2243/workspace/PERV.html/.venv/bin/gunicorn -w 2 -b 0.0.0.0:5000 app:app
Restart=on-failure
User=ug2243

[Install]
WantedBy=multi-user.target
```

## 数据说明

- 元数据列：`Sequence.ID, Category, Motif, TSD, Identity, TE_type, Insertion_Time, Kimura.distance, ERV.type (γ.ERV / β.ERV), Abbretiation, Group (Eastern / Western)`
- BED 文件均为 6 列：`seq_id, start, end, name, score, strand`，坐标为 0-based 半开区间。
- ORF 文件中的 `name` 取值：`LTR / GAG / POL / ENV`；其中 LTR 为非编码区，蛋白模式自动屏蔽。
- 结构域文件中的 `name` 取值：`GAG / AP / RT / RNaseH / INT / ENV`，全部可翻译。
- 启动时若 `data/*.json` 不存在或源文件较新，会自动重新构建索引。

## 主要 API

| Method | Path | 说明 |
| ---- | ---- | ---- |
| GET | `/api/overview/stats` | γ/β、Group、Abbretiation 计数；Identity / Insertion_Time / Kimura 直方图分桶 |
| GET | `/api/overview/table?q=&type=&group=&page=&size=` | 1165 条元数据分页查询 |
| GET | `/api/sequences/pass` | 139 条 ID + 长度 |
| GET | `/api/sequences/<sid>/regions?kind=orf\|domain` | 区间列表 + 序列长度 |
| GET | `/api/sequences/<sid>/dna?start=&end=&strand=&name=` | 区间 DNA + FASTA |
| GET | `/api/sequences/<sid>/protein?start=&end=&strand=&name=` | 标准遗传密码翻译后的蛋白 + FASTA |
| GET | `/api/sequences/<sid>/all-protein?kind=orf\|domain` | 该序列下所有可编码区间的多 FASTA（ORF 模式自动跳过 LTR） |
| GET | `/download/<filename>` | 受白名单限制的原始数据下载 |

翻译规则：直接对所选区间的 DNA 按标准密码子表逐三个碱基翻译；非 ACGT 或末尾不足 3 bp 的位置以 `X` 表示；遇到终止子保留 `*` 标记，不截断（前端展示完整序列）。`-` 链区间会先取反向互补再翻译（当前数据均为 `+` 链）。

## License

数据版权归原作者所有，本仓库的网站代码以 MIT 许可证发布（如需）。
